package org.library.utils;

import org.library.model.client;

public interface IDataStructure {
    public int rertun(client klient);
}
