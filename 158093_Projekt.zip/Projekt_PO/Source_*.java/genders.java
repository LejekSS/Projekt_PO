package org.library;

public enum genders {
    MEZCZYZNA,
    KOBIETA
}
