package org.library;

public enum workplaces {
    BIBLIOTEKARZ,
    ASYSTENT_BIBLIOTEKARZA,
    DYREKTOR,
    DOZORCA
}
