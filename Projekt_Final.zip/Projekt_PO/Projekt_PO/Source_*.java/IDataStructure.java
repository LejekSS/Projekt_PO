package org.library;

public interface IDataStructure {
    public int rertun(client klient);
}
