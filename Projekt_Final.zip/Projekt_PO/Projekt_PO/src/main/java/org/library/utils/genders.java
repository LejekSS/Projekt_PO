package org.library.utils;

public enum genders {
    MEZCZYZNA,
    KOBIETA
}
