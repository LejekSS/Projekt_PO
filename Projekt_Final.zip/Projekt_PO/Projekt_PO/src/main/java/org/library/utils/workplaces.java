package org.library.utils;

public enum workplaces {
    BIBLIOTEKARZ,
    ASYSTENT_BIBLIOTEKARZA,
    DYREKTOR,
    DOZORCA
}
